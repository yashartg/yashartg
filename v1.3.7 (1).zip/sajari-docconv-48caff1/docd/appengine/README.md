# Deploying docd to AppEngine

Within this directory run:

```
gcloud app deploy
```
