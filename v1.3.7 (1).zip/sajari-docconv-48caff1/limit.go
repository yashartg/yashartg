package docconv

const maxBytes = 20 << 20 // 20MB
